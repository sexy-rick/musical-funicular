# Alium release repository guide

This public repository is for distribution only. Keep its existing LICENSE; never upload private app source, signing keys, passwords, Telegram credentials or private repository history. GitHub generates source archives from repository tags, so tags must contain only public-safe files. Review licenses and third-party obligations before distribution.

## First install

Install the first updater-enabled APK manually after its build and verification. It must have the same application ID and signing key as the installed Alium and a higher version code. Do not uninstall just to force installation: uninstalling may erase private session and history data. Android and the user control installation and permission prompts.

## Publishing a later update

1. Build a later signed `app-release.apk` with a higher version code and the same signing key. Keep the previously installed signed APK privately as the baseline.
2. From the private source workspace with Android SDK `apkanalyzer` and `apksigner` on PATH, run the private `android-app/scripts/create_update_metadata.py` tool with `--apk`, `--baseline`, `--tag` and `--notes` arguments. Use the actual release tag and genuine UTF-8 release notes. The tool checks the package, version and certificate and derives the size and SHA-256 from the actual APK. Review its `update.json` output; do not publish placeholders.
3. In this repository create a draft GitHub release for that exact tag. Attach the exact verified files named `app-release.apk` and `update.json`, review them, then publish the release manually.
4. Verify `https://github.com/Alchemiisst/Alium/releases/latest/download/update.json` without credentials and test on an Android device. A public release does not exist until you publish one; the updater and asset redirects require real-device testing.

Alium checks on app launch at most once per 24 hours, and offers a manual Settings check. “Remind tomorrow” delays the automatic prompt for that version; manual checks remain available. Android's installer makes the final signature decision. The metadata hash detects corruption but does not authenticate a compromised GitHub release account, so protect the account and signing key. Key rotation is not supported by the current exact-certificate check. GitHub Actions artifacts expire and are not a permanent public release channel.
