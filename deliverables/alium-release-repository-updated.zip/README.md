# Alium releases

This repository is intended for public Android releases of Alium by Marketplace Trader. Alium's application source is maintained separately.

## Downloads

When a release is published, use the APK attached to its GitHub Release. No release is included in this repository starter.

Updater-enabled builds can check for later releases in Settings and on app launch. The first updater-enabled build must be installed manually. Check the release guide for compatibility and installation details.

## Support

- Website: https://marketplacetrader.great-site.net/
- Community: https://t.me/minecraft_group_chat_friends
- Contact: https://t.me/alchemisst

Minecraft is a trademark of its respective owners. Alium is an independent community project.
