import { fetch } from 'sdk';
import { extractAddonDetails, fetchPackMeta } from 'lib/marketplace';
import { getBotJson, getBotNumber } from 'lib/store';

// Production diagnostics (read-only). Invoked via: tgcloud run endpoints/pfdiag '{"uuid":"..."}'
export default async function (input) {
  const uuid = String((input && input.uuid) || 'f4e58e68-f2f2-4f34-be52-7fcaca92fa6f');
  const out = { uuid };
  let t = Date.now();
  console.log('PFDIAG start ' + uuid);
  try {
    const res = await fetch('https://www.bedrockexplorer.com/marketplace-content/' + uuid, {
      headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'text/html,application/xhtml+xml' }
    });
    out.bedrockStatus = res.status;
    out.bedrockMs = Date.now() - t;
    console.log('PFDIAG bedrock ' + res.status + ' ' + out.bedrockMs + 'ms');
    if (res.ok) await res.text();
  } catch (e) {
    out.bedrockError = String((e && e.message) || e);
    out.bedrockMs = Date.now() - t;
    console.log('PFDIAG bedrock ERROR ' + out.bedrockError + ' ' + out.bedrockMs + 'ms');
  }
  t = Date.now();
  try {
    const d = await extractAddonDetails(uuid);
    out.extractOk = Boolean(d);
    out.extractTitle = d ? d.title : '';
    out.extractMs = Date.now() - t;
    console.log('PFDIAG extract ' + out.extractOk + ' ' + out.extractMs + 'ms');
  } catch (e) {
    out.extractError = String((e && e.message) || e);
    out.extractMs = Date.now() - t;
    console.log('PFDIAG extract ERROR ' + out.extractError);
  }
  t = Date.now();
  try {
    const m = await fetchPackMeta(uuid);
    out.playfabVersion = m ? m.version : null;
    out.playfabModified = m ? m.modified : null;
    out.playfabMs = Date.now() - t;
    console.log('PFDIAG playfab ' + JSON.stringify(m ? { v: m.version } : null) + ' ' + out.playfabMs + 'ms');
  } catch (e) {
    out.playfabError = String((e && e.message) || e);
    out.playfabMs = Date.now() - t;
    console.log('PFDIAG playfab ERROR ' + out.playfabError);
  }
  t = Date.now();
  try {
    out.totalReqs = await getBotNumber('total_reqs', 0);
    out.indexLen = (await getBotJson('request_bundle_index', []) || []).length;
    out.dbMs = Date.now() - t;
    console.log('PFDIAG db totalReqs=' + out.totalReqs + ' indexLen=' + out.indexLen + ' ' + out.dbMs + 'ms');
  } catch (e) {
    out.dbError = String((e && e.message) || e);
    console.log('PFDIAG db ERROR ' + out.dbError);
  }
  console.log('PFDIAG done');
  return out;
}
