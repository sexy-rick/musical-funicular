import { handleAdminMessage } from 'lib/admin';
import { handleStart } from 'lib/start';
import { handleStatsMessage } from 'lib/stats';
import { handleResetMessage } from 'lib/reset';
import { handleSupportMessage } from 'lib/support';
import { handleDeleteBundleMessage } from 'lib/delete_bundle';
import { handleGroupSearchMessage } from 'lib/group_search';
import { handleLegacyRequest, handleRequest, handleRequestLink, handleRequestSearchResult } from 'lib/request';

export default async function (message) {
  if (await handleRequestSearchResult(message)) return;
  if (await handleAdminMessage(message)) return;
  if (await handleResetMessage(message)) return;
  if (await handleStatsMessage(message)) return;
  if (await handleSupportMessage(message)) return;
  if (await handleDeleteBundleMessage(message)) return;
  if (await handleStart(message)) return;
  if (await handleRequest(message)) return;
  if (await handleRequestLink(message)) return;
  if (await handleLegacyRequest(message)) return;
  if (await handleGroupSearchMessage(message)) return;
}

