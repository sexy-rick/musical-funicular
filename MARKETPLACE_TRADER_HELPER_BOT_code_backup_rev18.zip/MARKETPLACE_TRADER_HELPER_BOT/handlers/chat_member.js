import { handleInfoChatMember } from 'lib/info';

export default async function (chatMemberUpdated) {
  await handleInfoChatMember(chatMemberUpdated);
}
