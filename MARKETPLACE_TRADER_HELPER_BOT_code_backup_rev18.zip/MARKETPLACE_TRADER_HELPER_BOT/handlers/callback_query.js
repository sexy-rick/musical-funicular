import { handleAdminCallback } from 'lib/admin';
import { handleRequestCallback } from 'lib/request';
import { handleGroupSearchCallback } from 'lib/group_search';

export default async function (callbackQuery) {
  if (await handleAdminCallback(callbackQuery)) return;
  if (await handleGroupSearchCallback(callbackQuery)) return;
  if (await handleRequestCallback(callbackQuery)) return;
}

