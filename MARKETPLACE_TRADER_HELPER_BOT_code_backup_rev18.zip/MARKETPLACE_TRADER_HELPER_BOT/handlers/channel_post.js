import { handleRequestBoom } from 'lib/request';

export default async function (channelPost) {
  if (await handleRequestBoom(channelPost)) return;
}
