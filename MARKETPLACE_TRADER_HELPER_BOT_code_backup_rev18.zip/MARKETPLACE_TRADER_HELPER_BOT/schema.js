import { table, integer, text } from 'sdk/db';

export const users = table('users', {
  id: integer('id').primaryKey(),
  firstName: text('first_name'),
  username: text('username'),
  isCountedInTotal: integer('is_counted_in_total').notNull().default(0),
  joinedAt: integer('joined_at'),
  updatedAt: integer('updated_at')
});

export const botState = table('bot_state', {
  key: text('key').primaryKey(),
  value: text('value'),
  updatedAt: integer('updated_at')
});

export const userState = table('user_state', {
  id: text('id').primaryKey(),
  userId: integer('user_id').notNull(),
  key: text('key').notNull(),
  value: text('value'),
  updatedAt: integer('updated_at')
});
